# AlgCom 2017-18: Zachary Karate Club

0. Compute the PageRank values of the vertices with damping factor 0.
0. Compute the strength (sum of weights) of the vertices and normalize to an average of 1.
0. Comment on the relation of results (1) and (2).
