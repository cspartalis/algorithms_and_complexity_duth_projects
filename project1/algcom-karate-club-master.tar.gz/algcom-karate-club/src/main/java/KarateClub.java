import com.google.common.io.Resources;
import gr.james.influence.graph.DirectedGraph;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

public final class KarateClub {
    public static DirectedGraph<Integer, Object> loadKarateClub() throws IOException {
        final int VERTEX_COUNT = 34;

        final DirectedGraph<Integer, Object> g = DirectedGraph.create();
        for (int i = 1; i <= VERTEX_COUNT; i++) {
            g.addVertex(i);
        }

        final List<String> lines = Resources.readLines(Resources.getResource("karate-valued.txt"),
                StandardCharsets.UTF_8);
        for (int v = 0; v < lines.size(); v++) {
            final String[] split = lines.get(v).split(" ");
            assert split.length == VERTEX_COUNT;
            for (int w = 0; w < split.length; w++) {
                final double weight = Double.parseDouble(split[w]);
                if (weight != 0) {
                    g.addEdge(v + 1, w + 1, null, weight);
                }
            }
        }

        return g.asUnmodifiable();
    }
}
